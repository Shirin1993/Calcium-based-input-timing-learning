#!/bin/bash
#SBATCH --partition medium
##SBATCH --qos=1h
#SBATCH -o job_output/job-%J.out
#SBATCH -C scratch
#SBATCH -c 2
#SBATCH -n 1
##SBATCH -A all
#SBATCH --array=1-400



module purge
module pytho
source ./mypy/bin/activate
conda activate mypy
source activate mypy
python3 -u plotSTDP.py  $SLURM_ARRAY_TASK_ID




import sys
import pylab as pl
import numpy as np
import random as rnd
import os
import pandas as pd
import time as tm

import seaborn as sns


pathsave = '/scratch/users/shafieekamal/GeneralRuns/bashrun/7stim/higherthresholds/thresholds/otherthresholds/medium_thresholds/matched/'
def weights(frequency,th_id):

    N_spine = 16
    NOS_out = 6
    NOS_in = N_spine - NOS_out # number of all spines inside the cluster with a L length
    NOunstim = 3  # number of unstimulated spines in a L length
    
    Thetta= [[70,50]]
    thetp = list([Thetta[i][0] for i in range( len(Thetta))])
    thetd = list([Thetta[i][1] for i in range( len(Thetta))])
    Pot_threshold = (np.array(thetp))
    Dep_threshold = (np.array(thetd))
    #time_w = np.linspace(0,(time*dt),time) 


    pathf = '/scratch/users/shafieekamal/GeneralRuns/bashrun/7stim/higherthresholds/thresholds/otherthresholds/medium_thresholds/'+str(frequency)+'Hz/'
#     th_id = 1   
    realization = 20
    in_st = 0
    in_unst = 0
    out_unst =0
    final_w_stim = []
    final_w_Unstim = []
    final_w_Unstim_far = []
    for i in range ( realization):
    
        readpath = pathf+'threshold'+str(Pot_threshold[th_id])+'_'+str(Dep_threshold[th_id])+'/r_'+str(i)+'/'
        spine_dfunpickle = pd.read_pickle(readpath+"spine_arrangement.pkl")
        w0_dfunpickle =  pd.read_pickle(readpath+"w.pkl") 
        StimIndx = spine_dfunpickle.index[spine_dfunpickle['stim'] == 1].tolist() # return indices of stimulated spines[0-N_spine]
        N_spine = len(spine_dfunpickle)
        Unstim =  list(set(range(N_spine))- set(StimIndx)) #all Unstimulated spines
        I_N_Unstim = Unstim[int(NOS_out/2):-int(NOS_out/2)] # inside unstimualted spines 
        O_N_Unstim = list(set(Unstim)- set(I_N_Unstim))
        # Avg stimulated spine 

        for i in StimIndx:
            in_st = w0_dfunpickle['spine'+str(i)]-w0_dfunpickle['spine'+str(i)][0] + in_st
        in_st = in_st/len(StimIndx)
        final_w_stim.append(list(in_st)[-1])
        # Avg Unstimulated inside spine

        for i in I_N_Unstim:
            in_unst = w0_dfunpickle['spine'+str(i)]-w0_dfunpickle['spine'+str(i)][0] + in_unst
        in_unst = in_unst/len(I_N_Unstim)
        final_w_Unstim.append(list(in_unst)[-1])
        # Avg Unstimulated Outside spine

        for i in O_N_Unstim:
            out_unst = w0_dfunpickle['spine'+str(i)]-w0_dfunpickle['spine'+str(i)][0] + out_unst
        out_unst = out_unst/len(O_N_Unstim)
        final_w_Unstim_far.append(list(out_unst)[-1])
    return final_w_stim,final_w_Unstim,final_w_Unstim_far



Thetta= [[70,50]]
thetp = list([Thetta[i][0] for i in range( len(Thetta))])
thetd = list([Thetta[i][1] for i in range( len(Thetta))])
Pot_threshold = (np.array(thetp))
Dep_threshold = (np.array(thetd))
for th_id in range(len(Pot_threshold)):

    dff2= pd.DataFrame({'w_final':weights(2,th_id)[0]+weights(2,th_id)[1]+weights(2,th_id)[2]  ,'activity':['stim']*len(weights(2,th_id)[0]) +['Unstim']*len(weights(2,th_id)[1])+['Unstim_far']*len(weights(2,th_id)[2]) })
    dff2['frequency'] = 2 # the frequency

    result = dff2

    pl.rcParams.update({'font.size': 16}) 
    tips = result#sns.load_dataset("result")

    g = sns.catplot(
        x="frequency", 
        y="w_final", 
        hue="activity",  
        data=tips, 
        kind="bar",
        ci = "sd", 
        edgecolor="black",
        errcolor="black",
        errwidth=1.5,
        capsize = 0.1,
        height=4, 
        aspect=1 ,
        alpha=0.9,palette=['cadetblue', 'lightcoral', 'khaki'],
        )
    # Remove the old legend
    g.set_xticklabels(rotation=90)
    t=sns.stripplot(x='frequency', 
                  y='w_final',
                  hue="activity",
                  data=result,
                  dodge=True,
                  color='k',
                  size = 2);
    pl.xlabel(' ')
    pl.ylabel('$\Delta w$')
    t.legend_.remove()
    pl.savefig(pathsave+'2HzW_Frec__th_P_'+str(Pot_threshold[th_id])+'th_d_'+str(Dep_threshold[th_id])+'.svg', bbox_inches='tight',facecolor='w')

    
    
    


Thetta= [[70,50]]
thetp = list([Thetta[i][0] for i in range( len(Thetta))])
thetd = list([Thetta[i][1] for i in range( len(Thetta))])
Pot_threshold = (np.array(thetp))
Dep_threshold = (np.array(thetd))
for th_id in range(len(Pot_threshold)):


    dff100= pd.DataFrame({'w_final':weights(100,th_id)[0]+weights(100,th_id)[1]+weights(100,th_id)[2]  ,'activity':['stim']*len(weights(100,th_id)[0]) +['Unstim']*len(weights(100,th_id)[1])+['Unstim_far']*len(weights(100,th_id)[2]) })
    dff100['frequency'] = 100 # the frequency

    result = dff100

    pl.rcParams.update({'font.size': 16}) 
    tips = result#sns.load_dataset("result")

    g = sns.catplot(
        x="frequency", 
        y="w_final", 
        hue="activity",  
        data=tips, 
        kind="bar",
        ci = "sd", 
        edgecolor="black",
        errcolor="black",
        errwidth=1.5,
        capsize = 0.1,
        height=4, 
        aspect=1 ,
        alpha=0.9,palette=['cadetblue', 'lightcoral', 'khaki'],
        )
    # Remove the old legend
    g.set_xticklabels(rotation=90)
    t=sns.stripplot(x='frequency', 
                  y='w_final',
                  hue="activity",
                  data=result,
                  dodge=True,
                  color='k',
                  size = 2);
    pl.xlabel(' ')
    pl.ylabel('$\Delta w$')
    t.legend_.remove()
    pl.savefig(pathsave+'100HzW_Frec__th_P_'+str(Pot_threshold[th_id])+'th_d_'+str(Dep_threshold[th_id])+'.svg', bbox_inches='tight',facecolor='w')

    
    
    
    
    
    
    
    
    
    
    
    
    
        



Thetta= [[70,50]]
thetp = list([Thetta[i][0] for i in range( len(Thetta))])
thetd = list([Thetta[i][1] for i in range( len(Thetta))])
Pot_threshold = (np.array(thetp))
Dep_threshold = (np.array(thetd))
for th_id in range(len(Pot_threshold)):


    dff150= pd.DataFrame({'w_final':weights(150,th_id)[0]+weights(150,th_id)[1]+weights(150,th_id)[2]  ,'activity':['stim']*len(weights(150,th_id)[0]) +['Unstim']*len(weights(150,th_id)[1])+['Unstim_far']*len(weights(150,th_id)[2]) })
    dff150['frequency'] = 150 # the frequency

    result = dff150

    pl.rcParams.update({'font.size': 16}) 
    tips = result#sns.load_dataset("result")

    g = sns.catplot(
        x="frequency", 
        y="w_final", 
        hue="activity",  
        data=tips, 
        kind="bar",
        ci = "sd", 
        edgecolor="black",
        errcolor="black",
        errwidth=1.5,
        capsize = 0.1,
        height=4, 
        aspect=1 ,
        alpha=0.9,palette=['cadetblue', 'lightcoral', 'khaki'],
        )
    # Remove the old legend
    g.set_xticklabels(rotation=90)
    t=sns.stripplot(x='frequency', 
                  y='w_final',
                  hue="activity",
                  data=result,
                  dodge=True,
                  color='k',
                  size = 2);
    pl.xlabel(' ')
    pl.ylabel('$\Delta w$')
    t.legend_.remove()
    pl.savefig(pathsave+'150HzW_Frec__th_P_'+str(Pot_threshold[th_id])+'th_d_'+str(Dep_threshold[th_id])+'.svg', bbox_inches='tight',facecolor='w')


#!/bin/bash
#SBATCH -p medium
#SBATCH -t 48:00:00
##SBATCH --qos=long
#SBATCH -o job_output/job-%J.out
#SBATCH -C scratch
#SBATCH -c 2
#SBATCH -A all
#SBATCH --array=1


module purge
#module load python/3.9.0 
module load anaconda3

python3 -u bashTheCode.py  $SLURM_ARRAY_TASK_ID




conda deactivate




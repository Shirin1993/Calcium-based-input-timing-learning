import sys
import pylab as pl
#from scitools import *
import scipy.sparse
import scipy.sparse.linalg
import numpy as np
from scipy import linalg
import random as rnd
import itertools as itertools
import os


numberofspike = 2
numberOfBursts = 5


gammaP = 2.3#321.808
gammaD = 1.0#200


Depression_thr = np.linspace(0.1,10,20)
Potentiation_thr = np.linspace(0.1,10,20)
thresholds = np.round(list(itertools.product(Depression_thr,Potentiation_thr)),3)

jobid = os.getenv('SLURM_ARRAY_TASK_ID')
jobid = int(jobid)-1



ppath = '/scratch/users/shafieekamal/GeneralRuns/bashrun/STDP/repetition/Distance1_spike2/'
parent_dir = os.path.join(ppath, f"burstsize{numberofspike}")





os.makedirs(f"{parent_dir}", exist_ok=True)
ith = thresholds[jobid]
thP = ith[0]
thD = ith[1]
os.makedirs(f"{parent_dir}/thP{thP}_thD{thD}", exist_ok=True)


path =  f"{parent_dir}/thP{thP}_thD{thD}/"
os.mkdir(path +"/n")
path = path+'n/'


N_spine = 2  # number of spines
N_dend = 320  # number of dendritic segments
L = 80 * 1e-6  # 10 um     #Total length of dendritic branch in [m]
dx = L / (N_dend)  # Length of each dendritic segments in [m]
timetotal = 7000 * 1e-3  # Total time of simulation in [s]
dt = 25 * 1e-5  # s   #Timestep duration in [s]
time = int(timetotal / dt)  # Number of steps


spine_list = [160, 164]   # 36 40 44 48 52 56 60 64 68 72

########################

##########################################################3
Z=2

Deff =  220 * 1e-12  #m^2/s
tau = 0.08#10 * 1e-3 #s
tauspine = 0.08#10 * 1e-3

Faraday = 96485.309 #C/mol
y = 0.11
radius= 1 * 1e-6  #um #den radius
Lneck = 0.5* 1e-6 #um   #0.16 -1.8 mean .98
neckradius= 0.1 * 1e-6 #um 0.06-0.29 /2    0.175 mean /2 =0.0875
spineradius = 0.34 * 1e-6 #  #um 0.26-1.10 /2  mean 0.68 /2 = 0.34
S = np.pi*radius**2
S_prime = np.pi*neckradius**2
Vcomp = dx*np.pi*radius**2
ks =  (4*Deff*neckradius)/Vcomp
Vs = (4/3)*np.pi*spineradius**3
tau_prime = Vs/(4*Deff*neckradius) +(Lneck**2)/(2*Deff)
ks_prime = 1/tau_prime


w0 = 0.5#rnd.uniform(0.1, 1)
w1 = 0.5# rnd.uniform(0.1, 1)


def ttoms(milsec):
    # dt = 1e-6
    dt = 25 * 1e-5  # s   #timestep
    return int(milsec/(dt * 1e3))
input_time = ttoms(1)  # current input time

adj = np.zeros(N_dend)
adj[spine_list] = 1
delays = [0,2,4,6,8,10,15,20,30,40,50,60,80,100,150,200]
taudec = 1*1e-3 #s
I0 = 0.1*1e-12


B = []
for it in range(time):
    B.append(I0 * np.exp(-it * dt / taudec))

for dly in delays:
    train = np.zeros((N_spine,time))  #current I(mA) list for spine

    dts = ttoms(10)  #                    ACHTUNG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!must be   ttoms(0.1)
    delay = ttoms(dly)
    interval = ttoms(700)
    
    for d in range(numberOfBursts):
        for i in range(numberofspike):
            tt = i * dts
            train[0,delay + d * interval + input_time + i * dts] = 1
        train[1,input_time + d * interval] = 1
    xs = np.zeros((N_spine, time))


    for spn in range(N_spine):

        cc = np.convolve(train[spn,:], B)
        xs[spn, :] = cc[0:int((len(cc) + 1) / 2)]

    alpha = dt*ks
    beta = dt*ks_prime
    F = Deff * dt / dx ** 2
    gamma = dt*y/(Z*Vs*Faraday)
    dec = dt/tau
    decspine = dt/tauspine

    sincm = 1
    if N_dend == 1:
      sincm = 0
    A = np.zeros((N_dend+N_spine,N_dend+N_spine))
    for i in range(N_spine+1,N_dend+N_spine-1):
        A[i, i] = 1 + 2*F  +(adj[i-N_spine])*alpha + dec
    A[N_spine, N_spine] = 1 + (sincm*F) + (adj[0])*alpha   #first dnd
    A[N_dend+N_spine-1,N_dend+N_spine-1]= 1 + (sincm*F) + (adj[N_dend-1])*alpha
    for i in range(N_spine,N_dend+N_spine-1):
        A[i, i + 1] = -F
    for i in range(N_spine+1,N_dend+N_spine):
        A[i, i - 1] = -F
    for i in range(N_spine):
        A[i,i] = 1+beta +decspine
    for i in range(N_spine):
        A[i,N_spine+spine_list[i]] = - alpha
    for i in range(N_spine):
        A[N_spine + spine_list[i],i] = - beta


    b=np.zeros((N_spine+N_dend,time))
    U = np.zeros((N_spine+N_dend,time))

    U[0:N_spine,0] =0# 6.02 * 1e-6
    U[N_spine:N_spine+N_dend,0] = 0

    def theta(ar):
        listt=np.zeros(len(ar))
        for values in range(len(ar)):
            if ar[values]>0:
                listt[values]=1
            if ar[values]<=0:
                listt[values]=0
        return listt
    weight= np.zeros((N_spine,time))

    weight[0,0] = w0
    weight[1,0] = w1
    # print(weight[0,0],weight[1,0])



    for t in range(time-1):
        b[0:N_spine,t] = gamma * xs[:, t] * weight[:,t]
        C = U[:, t] + b[:, t]
        X = linalg.solve(A, C )
        weight[:,t+1] = weight[:,t] + dt * (gammaP*(1-weight[:,t])*theta(1e6*U[0:N_spine, t]-thP)-gammaD*weight[:,t]*theta(1e6*U[0:N_spine, t]-thD))
        U[:,t+1] = np.asarray(X).flatten()


    np.savetxt(path + 'w_' + "thetp" + str(thP) + "delay" + str(dly) + '.txt', weight,fmt='%1.5e')



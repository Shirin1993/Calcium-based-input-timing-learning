change the seed number to [100,200,1254] to get all the fixed configurations

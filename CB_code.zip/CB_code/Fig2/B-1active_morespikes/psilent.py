import sys
import pylab as pl

import scipy.sparse
import scipy.sparse.linalg
import numpy as np
from scipy import linalg
import random as rnd

import os
numberofspike = 7
ppath = '/home/shirin/phd/paper/paper_jan2023/paper2024/figure2/1active/'
parent_dir = os.path.join(ppath, "burstsize"+str(numberofspike))
os.mkdir(parent_dir)
path = ppath +"burstsize"+str(numberofspike)+'/'
parent_dir = os.path.join(path, "p")
os.mkdir(parent_dir)
path = path+'p/'


def location(i, dx):
    return np.round(1e6 * (2 * i + 1) * dx / 2, 4)


nd = 320
N_dend = nd
L = 80 * 1e-6  # 10 um
dx = L / (N_dend)
timetotal = 1000 * 1e-3  # s
dt = 25 * 1e-5  # s   #timestep
time = int(timetotal / dt)  # steps
Deff = 220 * 1e-12  # m^2/s
tau = 0.08  # 10 * 1e-3 #s
tauspine = 0.08  # 10 * 1e-3

Faraday = 96485.309  # C/mol
y = 0.11
radius = 1 * 1e-6  # um #den radius
Lneck = 0.5 * 1e-6  # um   #0.16 -1.8 mean .98
neckradius = 0.1 * 1e-6  # um 0.06-0.29 /2    0.175 mean /2 =0.0875
spineradius = 0.34 * 1e-6  # #um 0.26-1.10 /2  mean 0.68 /2 = 0.34
S = np.pi * radius ** 2
S_prime = np.pi * neckradius ** 2
Vcomp = dx * np.pi * radius ** 2
ks = (4 * Deff * neckradius) / Vcomp
Vs = (4 / 3) * np.pi * spineradius ** 3
tau_prime = Vs / (4 * Deff * neckradius) + (Lneck ** 2) / (2 * Deff)
ks_prime = 1 / tau_prime

##########################################################3
Z=2
N_spine = 2



w0 = 0.5 #rnd.uniform(0.1, 1)
w1 = 0.5 # rnd.uniform(0.1, 1)


def ttoms(milsec):
    # dt = 1e-6
    dt = 25 * 1e-5  # s   #timestep
    return int(milsec/(dt * 1e3))

input_time = ttoms(1) #current input time

spine_list = [100, 103] # ,48]# [int(N_dend // 6), int(N_dend // 4), int(N_dend // 3)]#[int(N_dend//2)] #can be 0,1,...(Nd-1) int(N_dend//4),int(N_dend//3),
adj = np.zeros(N_dend)
adj[spine_list] = 1
delays = [1]
taudec = 1*1e-3 #s
I0 = 0.1*1e-12






B = []
for it in range(time):
    B.append(I0 * np.exp(-it * dt / taudec))

for dly in delays:
    train = np.zeros((N_spine,time))  #current I(mA) list for spine

    dts = ttoms(2)  #                    ACHTUNG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!must be   ttoms(0.1)
    delay = ttoms(dly)
    interval = ttoms(200)
    numberOfBursts = 5
    for d in range(numberOfBursts):
        for i in range(numberofspike):
            tt = i * dts
            train[0,d * interval + input_time + i * dts] = 1
        train[1,input_time+tt + d * interval + delay] = 0

    xs = np.zeros((N_spine, time))


    for spn in range(N_spine):

        cc = np.convolve(train[spn,:], B)
        xs[spn, :] = cc[0:int((len(cc) + 1) / 2)]

    alpha = dt*ks
    beta = dt*ks_prime
    F = Deff * dt / dx ** 2
    gamma = dt*y/(Z*Vs*Faraday)
    dec = dt/tau
    decspine = dt/tauspine

    sincm = 1
    if N_dend == 1:
      sincm = 0
    A = np.zeros((N_dend+N_spine,N_dend+N_spine))
    for i in range(N_spine+1,N_dend+N_spine-1):
        A[i, i] = 1 + 2*F  +(adj[i-N_spine])*alpha + dec
    A[N_spine, N_spine] = 1 + (sincm*F) + (adj[0])*alpha   #first dnd
    A[N_dend+N_spine-1,N_dend+N_spine-1]= 1 + (sincm*F) + (adj[N_dend-1])*alpha
    for i in range(N_spine,N_dend+N_spine-1):
        A[i, i + 1] = -F
    for i in range(N_spine+1,N_dend+N_spine):
        A[i, i - 1] = -F
    for i in range(N_spine):
        A[i,i] = 1+beta +decspine
    for i in range(N_spine):
        A[i,N_spine+spine_list[i]] = - alpha
    for i in range(N_spine):
        A[N_spine + spine_list[i],i] = - beta


    b=np.zeros((N_spine+N_dend,time))
    U = np.zeros((N_spine+N_dend,time))

    U[0:N_spine,0] =0# 6.02 * 1e-6
    U[N_spine:N_spine+N_dend,0] = 0

    def theta(ar):
        listt=np.zeros(len(ar))
        for values in range(len(ar)):
            if ar[values]>0:
                listt[values]=1
            if ar[values]<=0:
                listt[values]=0
        return listt
    weight= np.zeros((N_spine,time))

    weight[0,0] = w0
    weight[1,0] = w1
    print(weight[0,0],weight[1,0])
    gammaP = 2.3#321.808
    gammaD = 1.0#200
    thP = 4
    thD = 2

    for t in range(time-1):
        b[0:N_spine,t] = gamma * xs[:, t] * weight[:,t]
        C = U[:, t] + b[:, t]
        X = linalg.solve(A, C )
        weight[:,t+1] = weight[:,t] + dt * (gammaP*(1-weight[:,t])*theta(1e6*U[0:N_spine, t]-thP)-gammaD*weight[:,t]*theta(1e6*U[0:N_spine, t]-thD))
        U[:,t+1] = np.asarray(X).flatten()


    np.savetxt(path + 'w_' + "thetp" + str(thP) + "delay" + str(dly) + '.txt', weight,fmt='%1.5e')
    for isp in range(N_spine):
        upthetaP = len((np.where(1e6 * U[isp, :] > thP))[0]) * dt * 1e3
        upthetaD = len((np.where(1e6 * U[isp, :] > thD))[0]) * dt * 1e3
        with open(path +'time'+'spine'+str(isp) + "thetp" + str(thP) + "delay" + str(dly) + '.txt', 'w') as f:
            f.write(str(upthetaP))
            f.write('\n')
            f.write(str(upthetaD))
        f.close()
    ################  PLOTS   #################
    pl.rcParams.update({'font.size': 18})
    steps=time
    xtime=np.linspace(0,(steps*dt*1e3),steps) #*1e3
    loc = []
    for i in range(N_dend):
        loc.append(np.round(1e6*(2 * i + 1) * dx / 2, 4))
    x = 1e6*np.linspace(0, L, N_dend)  # mesh points in space
    for i in range(N_spine):
        pl.plot(xtime, 1e6* U[i, :], '-',linewidth=5)  # , label = 'spine = '+str(i))
#    pl.title('both spines')
    pl.plot([0, max(xtime)], [thD, thD], '--')
    pl.plot([0, max(xtime)], [thP, thP], '--')
#    pl.grid()
    pl.ylabel(' Ca [\u03bc M]')
    pl.xlabel('time(ms)')

    pl.xlim(0,500)
    pl.ylim(0,35)
    pl.savefig(path + 'MagnifiedCadelay' + str(dly) + '.svg',facecolor='w', bbox_inches='tight')
    pl.close()
    pl.rcParams.update({'font.size': 16})
    for i in range(N_spine):
        pl.plot(xtime, 1e6 * U[i, :], '-')  # , label = 'spine = '+str(i))
#    pl.title('both spines')
    pl.plot([0, max(xtime)], [thD, thD], '--')
    pl.plot([0, max(xtime)], [thP, thP], '--')
#    pl.grid()
    pl.ylabel(' Ca [\u03bc M]')
    pl.xlabel('time(ms)')
    pl.savefig(path+'Cadelay' + str(dly) + '.svg',facecolor='w', bbox_inches='tight')

    # pl.show()
    pl.close()

    for i in range(N_spine):
        pl.plot(xtime,weight[i, :],'-',label=str(i))
    pl.legend()
    pl.xlabel('time(ms)')
    pl.ylabel('weight')
    pl.savefig(path+'weightdelay' + str(dly) + '.svg')
    # pl.show()
    pl.close()


    for i in range(N_spine):
        pl.plot(xtime,xs[i, :]*1e12,'-',label=str(i))
    pl.legend()
    pl.title('input current ')
    pl.xlabel('time(ms)')
    pl.ylabel('current (pA)')
    pl.savefig(path+'Idelay' + str(dly) + '.svg',facecolor='w', bbox_inches='tight')
    pl.close()
    # pl.show()

print('done')

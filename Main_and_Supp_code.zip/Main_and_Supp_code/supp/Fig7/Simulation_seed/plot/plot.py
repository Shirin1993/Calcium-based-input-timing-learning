import sys
import pylab as pl
import numpy as np
import random as rnd
import os
import pandas as pd
import time as tm

import seaborn as sns


pathsave = '/scratch/users/shafieekamal/GeneralRuns/bashrun/7stim/sameconfig/seed100/plot/'
def weights(frq_idd,th_id):
    freq_list =[0.5, 1,2,10,20,40, 50, 60, 70 , 80, 85 ,90,  95,  97, 100, 105, 110, 115, 120, 125, 130, 135,140, 145, 147, 150, 155, 160]
    frequency = freq_list[frq_idd]

    N_spine = 16
    NOS_out = 6
    NOS_in = N_spine - NOS_out # number of all spines inside the cluster with a L length
    NOunstim = 3  # number of unstimulated spines in a L length
    
    Thetta= [70,50]

    Pot_threshold = Thetta[0]
    Dep_threshold = Thetta[1]
    #time_w = np.linspace(0,(time*dt),time) 


    pathf = '/scratch/users/shafieekamal/GeneralRuns/bashrun/7stim/sameconfig/seed100/'+str(frequency)+'Hz/'
#     th_id = 1   
    realization = 1
    in_st = 0
    in_unst = 0
    out_unst =0
    final_w_stim = []
    final_w_Unstim = []
    final_w_Unstim_far = []
    for i in range ( realization):
    
        readpath = pathf+'threshold'+str(Pot_threshold)+'_'+str(Dep_threshold)+'/r_'+str(i)+'/'
        spine_dfunpickle = pd.read_pickle(readpath+"spine_arrangement.pkl")
        w0_dfunpickle =  pd.read_pickle(readpath+"w.pkl") 
        StimIndx = spine_dfunpickle.index[spine_dfunpickle['stim'] == 1].tolist() # return indices of stimulated spines[0-N_spine]
        N_spine = len(spine_dfunpickle)
        Unstim =  list(set(range(N_spine))- set(StimIndx)) #all Unstimulated spines
        I_N_Unstim = Unstim[int(NOS_out/2):-int(NOS_out/2)] # inside unstimualted spines 
        O_N_Unstim = list(set(Unstim)- set(I_N_Unstim))
        # Avg stimulated spine 

        for i in StimIndx:
            in_st = w0_dfunpickle['spine'+str(i)]-w0_dfunpickle['spine'+str(i)][0] + in_st
        in_st = in_st/len(StimIndx)
        final_w_stim.append(list(in_st)[-1])
        # Avg Unstimulated inside spine

        for i in I_N_Unstim:
            in_unst = w0_dfunpickle['spine'+str(i)]-w0_dfunpickle['spine'+str(i)][0] + in_unst
        in_unst = in_unst/len(I_N_Unstim)
        final_w_Unstim.append(list(in_unst)[-1])
        # Avg Unstimulated Outside spine

        for i in O_N_Unstim:
            out_unst = w0_dfunpickle['spine'+str(i)]-w0_dfunpickle['spine'+str(i)][0] + out_unst
        out_unst = out_unst/len(O_N_Unstim)
        final_w_Unstim_far.append(list(out_unst)[-1])
    return final_w_stim,final_w_Unstim,final_w_Unstim_far



Thetta= [70,50]

Pot_threshold = Thetta[0]
Dep_threshold = Thetta[1]


freq_list = [0.5, 1,2,10,20,40, 50, 60, 70 , 80, 85 ,90,  95,  97, 100, 105, 110, 115, 120, 125, 130, 135,140, 145, 147, 150, 155, 160]


th_id =0

variables = {}
for fr_id in range(len(freq_list)):
    dff_name = 'var_{}'.format(fr_id) # create variable name with index i
    dff_value = pd.DataFrame({'w_final':weights(fr_id,th_id)[0]+weights(fr_id,th_id)[1] +weights(fr_id,th_id)[2]  ,'activity':['stim']*len(weights(fr_id,th_id)[0]) +['Unstim']*len(weights(fr_id,th_id)[1])+['Unstim_far']*len(weights(fr_id,th_id)[2]) })
    variables[dff_name] = dff_value
    variables[dff_name]['frequency'] = freq_list[fr_id] # the frequency
    

for i in range(len(freq_list)-1):
    
    if i==0:
        A = (variables['var_{}'.format(0)])
    if i!=0:
        A = dff_concat
    cnc =[A,variables['var_{}'.format(i+1)]]
    dff_concat=pd.concat(cnc)
    

result = dff_concat

result.to_pickle(pathsave+"concatedresult.pkl")
pl.rcParams.update({'font.size': 16}) 
tips = result#sns.load_dataset("result")

g = sns.catplot(
    x="frequency", 
    y="w_final", 
    hue="activity",  
    data=tips, 
    kind="bar",
    ci = "sd", 
    edgecolor="black",
    errcolor="black",
    errwidth=1.5,
    capsize = 0.1,
    height=4, 
    aspect=.7,
    alpha=0.5
    )
# Remove the old legend
g.set_xticklabels(rotation=90)
t=sns.stripplot(x='frequency', 
              y='w_final',
              hue="activity",
              data=result,
              dodge=True,
              color='k',
              size = 2);
pl.xlabel('frequency')
pl.ylabel('$\Delta w$')
t.legend_.remove()
pl.savefig(pathsave+'W_Frec__th_P_'+str(Pot_threshold)+'th_d_'+str(Dep_threshold)+'.svg', bbox_inches='tight',facecolor='w')


import numpy as np
import matplotlib.pylab as pl
from collections import OrderedDict
import os
N_dend = 320 #Number of dendritic compartments
N_spine = 2#N_dend  #Number of spines
El  = -70    #mV  #reversal potential of membrane
Eh = -70
timetotal= 300*1e-2 #s   
dt = 25 * 1e-5#s1e-6#s   #timestep     1e-3 ms
time = int(timetotal/dt) # steps
tau_A = 3*1e-3#s
tau_N = 15*1e-3#s
y_AMPA  = 1.0  #AMPA coefficient
y_NMDA  = 0.05  #NMDA coefficient
ccm = 0.01*1e-4        #F/cm^2   #membrane Capacitance per units of length
rrl = 200.0   #100-200 ohm.cm   (in references)  #axial resistivity per units of length
# rrs = 200.0   # 100-200  ohm.cm  (I put it same as axial resistance) #spine resistivity per units of length
rrm = 1000.0   #10000-20000   ohm.cm^2   (in references)  #membrane resistivity per units of length
radius = 1.0*1e-4      # cm    (in references) #radius of dendritic compartments
radius_spine = 1.*1e-4 # cm    (I put it the same as dendritic radius) #radius  of spine
length=80. #um
dl = (length/N_dend)*1e-4           #cm  or #1 um   (in references) #length of dendritic compartments
cm = 2*np.pi*radius*dl*ccm  #F (I did NOT convert it to Farad. if I do,it doesnt work!)#membrane Capacitance
cspine = 9.37*1e-15 #F
rl = rrl*dl/(np.pi*radius**2)  #will be in ohm  #axial resistance
# rs = 200 * 1e6   # #ohm
#rs = rrs*dl/(np.pi*radius_spine**2)   #will be in ohm #spine (neck? )resistance
rm =rrm/ (2*np.pi*radius*dl)  #will be in ohm #membrane resistance
G_md=1/rm      #1/ohm  #membrane conductivity
# G_ms = 1/(rs)  #1/ohm
ga = 1/(rl)    #1/ohm


#weights
theta_p = 1.1
theta_d = 1
cp = 2.3
cd = 1.0
init_w=1 #initial synaptic weights
ws = 0.5 ##attraction point

#calcium
Dd = 220 *1e-12  #m^2/s        #400 um^2/s   #for calcium
dxd= dl*1e-2  #m
a_opening = 0.049*1e-6 #m
a_NMDA = 1
a_VDCC = 2
tau_inactivation = 0.05   #0.05s


#synaptic input
receptor_radius = 25*1e-9 #m #25 nm,
gamma_fraction = 11./100
Faraday = 96485.309 #C/mol
z_valence = 2




rneck = 400*1e6
rhead = 1e8

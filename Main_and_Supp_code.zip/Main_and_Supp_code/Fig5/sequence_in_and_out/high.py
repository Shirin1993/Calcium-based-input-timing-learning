
import numpy as np
import pandas as pd
# import pickle
import matplotlib.pyplot as pl
# from scipy import signal
# from sklearn import linear_model
# from sklearn.metrics import roc_curve, roc_auc_score
# from tensorflow import keras
# import glob
import matplotlib
# import matplotlib.gridspec as gridspec
# import random as rnd
import parameters_many as pr
# from collections import OrderedDict
from scipy import linalg
import os
import shutil
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['svg.fonttype'] = 'none'
import tables
# import h5py
import matplotlib.pylab as plt



# configurations  = [[1,0,0,1],[0,1,1,0],[1,0,1,0],[0,1,0,1],[1,1,0,0],[0,0,1,1],[1,1,1,1],[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0],[1,1,1,0],[0,1,1,1],[1,0,1,1],[1,1,0,1]]#,[0,0,0,0]

# 
order = 'inward' # 'outward'  'inward'  
config = [1,1]


input_delay  = 37   # int(os.environ["delaytime"])
dist = 1   # float(os.environ["dist"])
variable0= input_delay
variable1= dist

variable0_variable1 = f"dt{variable0}dx{variable1}"

os.makedirs(f"./{variable0_variable1}/result/conf_{order}", exist_ok=True)

time= pr.time
signal = np.zeros((2,time))
# signal[:,10] = config
input_duration  = 10

initial_ignt = 50
#in the order ( timewise)

rpt = 300
signal[:,initial_ignt:input_duration+initial_ignt] = [[i] for i in config ]
repeated_patterns = 24
signal[0] = sum(np.roll(signal[0], i*rpt) for i in range(repeated_patterns))
signal[1] =  np.roll(signal[1],input_delay) 
signal[1] = sum(np.roll(signal[1], i*rpt) for i in range(repeated_patterns))
# signal[0] = signal[0] + np.roll( signal[0] ,rpt)+ np.roll( signal[0] ,2*rpt)+ np.roll( signal[0] ,3*rpt)+ np.roll( signal[0] ,4*rpt)+ np.roll( signal[0] ,5*rpt)+ np.roll( signal[0] ,6*rpt)+ np.roll( signal[0] ,7*rpt)+ np.roll( signal[0] ,8*rpt)+ np.roll( signal[0] ,9*rpt)+ np.roll( signal[0] ,10*rpt)+ np.roll( signal[0] ,11*rpt)
# signal[1] = signal[1] + np.roll( signal[1] ,rpt)  + np.roll( signal[1] ,2*rpt)+ np.roll( signal[1] ,3*rpt)+ np.roll( signal[1] ,4*rpt)+ np.roll( signal[1] ,5*rpt)+ np.roll( signal[1] ,6*rpt)+ np.roll( signal[1] ,7*rpt)+ np.roll( signal[1] ,8*rpt)+ np.roll( signal[1] ,9*rpt)+ np.roll( signal[1] ,10*rpt)+ np.roll( signal[1] ,11*rpt)

# signal[2] =  np.roll(signal[2],2*input_delay)
# signal[2] = signal[2] + np.roll( signal[2] ,rpt)  + np.roll( signal[2] ,2*rpt)
# signal[3] =  np.roll(signal[3],3*input_delay)
# signal[3] = signal[3] + np.roll( signal[3] ,rpt)  + np.roll( signal[3] ,2*rpt)
#pl.plot(signal[0])
#pl.savefig(f'trainsignal0.png',facecolor='w')
#pl.plot(signal[1])
#pl.savefig(f'trainsignal1.png',facecolor='w')
# #%%
#------first representation of the digit----------
def simulation(input_strains,order,variable1):
    factor = 1 # for the coefficient of the weight 
    ############ COMPARTMENTS  ####################
    N_dend = pr.N_dend #No of Dendritic compartment
    N_spine = pr.N_spine  #No of spines
    El  = pr.El #Reversal potential
    time= pr.time  #total time steps
    dt = pr.dt  #dt : time step in second
    dx = pr.dl * 1e-2  #cm to m
    ############ MORPHOLOGY ####################
    cm = pr.cm  #Membrane capacitance in Farad
    cspine = 10*cm#pr.cspine
    ############initial voltage ####################
    Eh = El#pr.Eh
    ####### INPUT###############
    spine_list = [160,160+int(variable1*4)]#[100,104,108,112]#[100,150,200,250]#np.arange(N_spine) #can be 0,1,...(Nd-1)
    adj = np.zeros(N_dend)
    adj[spine_list] = 1
    #####################Calcium#######################3
    Z=2
    Deff =  220 * 1e-12  #m^2/s  220
    tau = 0.08#10 * 1e-3 #s
    tauspine = 0.08#10 * 1e-3
    Faraday = 96485.309 #C/mol
    y = 0.11
    radius= 1 * 1e-6  #um #den radius
    Lneck = 0.5* 1e-6 #um   #0.16 -1.8 mean .98
    neckradius= 0.1 * 1e-6 #um 0.06-0.29 /2    0.175 mean /2 =0.0875
    spineradius = 0.34 * 1e-6 #  #um 0.26-1.10 /2  mean 0.68 /2 = 0.34
    # S = np.pi*radius**2
    # S_prime = np.pi*neckradius**2
    Vcomp = dx*np.pi*radius**2
    ks =  (4*Deff*neckradius)/Vcomp
    Vs = (4/3)*np.pi*spineradius**3
    tau_prime = Vs/(4*Deff*neckradius) +(Lneck**2)/(2*Deff)
    ks_prime = 1/tau_prime
    rhead =pr.rhead
    rneck=pr.rneck
    ################
    SIGMA = dt*(pr.radius*1e-2)/(2*pr.rrl*1e-2*pr.ccm*1e4*(pr.dl*1e-2)**2) #matrix component
    GAMMA = dt/(pr.rrm*(1e-4)*pr.ccm*1e4)  #matrix component
    beta =  dt/(rneck*cm)  #cm is in faraday
    Shead=  dt/(rhead*cspine)
    Sneck=dt/(rneck*cspine)
    Ghead =dt/cspine

    sincm=1
    if N_dend==1:
        sincm=0
    A = np.zeros((N_dend+N_spine,N_dend+N_spine))
    for i in range(N_spine+1,N_dend+N_spine-1):
        A[i, i] = 1 + 2*SIGMA + GAMMA +(adj[i-N_spine])*beta
    A[N_spine, N_spine] = 1 + (sincm*SIGMA) + GAMMA +(adj[0])*beta  #first dnd
    A[N_dend+N_spine-1,N_dend+N_spine-1]= 1 + (sincm*SIGMA) + GAMMA + (adj[N_dend-1])*beta
    for i in range(N_spine,N_dend+N_spine-1):
        A[i, i + 1] = -SIGMA
    for i in range(N_spine+1,N_dend+N_spine):
        A[i, i - 1] = -SIGMA
    for i in range(N_spine):
        A[i,i] = 1+Shead+Sneck
    for i in range(N_spine):
        A[i,N_spine+spine_list[i]] = - Sneck
    for i in range(N_spine):
        A[N_spine + spine_list[i],i] = - beta


    b = np.zeros((N_spine+N_dend, time))
    U = np.zeros((N_spine+N_dend, time))

    U[0:N_spine,0] = Eh
    U[N_spine:N_spine+N_dend,0] = El
    ################################################################
    alpha = dt * ks
    betacal = dt * ks_prime
    F = Deff * dt / dx ** 2
    gamma = dt * y / (Z * Vs * Faraday)
    dec = dt / tau
    decspine = dt / tauspine

    sincm = 1
    if N_dend == 1:
        sincm = 0
    Acal = np.zeros((N_dend + N_spine, N_dend + N_spine))
    for i in range(N_spine + 1, N_dend + N_spine - 1):
        Acal[i, i] = 1 + 2 * F + (adj[i - N_spine]) * alpha + dec
    Acal[N_spine, N_spine] = 1 + (sincm * F) + (adj[0]) * alpha  # first dnd
    Acal[N_dend + N_spine - 1, N_dend + N_spine - 1] = 1 + (sincm * F) + (adj[N_dend - 1]) * alpha
    for i in range(N_spine, N_dend + N_spine - 1):
        Acal[i, i + 1] = -F
    for i in range(N_spine + 1, N_dend + N_spine):
        Acal[i, i - 1] = -F
    for i in range(N_spine):
        Acal[i, i] = 1 + betacal + decspine
    for i in range(N_spine):
        Acal[i, N_spine + spine_list[i]] = - alpha
    for i in range(N_spine):
        Acal[N_spine + spine_list[i], i] = - betacal

    bcal = np.zeros((N_spine + N_dend, time))
    Ucal = np.zeros((N_spine + N_dend, time))

    Ucal[0:N_spine, 0] = 0  # 6.02 * 1e-6
    Ucal[N_spine:N_spine + N_dend, 0] = 0


    def theta(ar):
        listt = np.zeros(len(ar))
        for values in range(len(ar)):
            if ar[values] > 0:
                listt[values] = 1
            if ar[values] <= 0:
                listt[values] = 0
        return listt

    w0exc = 0.5#rnd.uniform(0.1, 1)
    w0inh =0#rnd.uniform(0.1, 1)
    # w_inh = -0.3
    weight = np.zeros((N_spine, time))
   
    weightexc = np.zeros((N_spine, time))
    weightexc[:, 0] = w0exc #list(np.round(np.random.random(N_spine),3))
    weightinh = np.zeros((N_spine, time))
    weightinh[:, 400:] = w0inh #list(np.round(np.random.random(N_spine),3))
    weight[:, 0] = w0exc
    #-----------------CAlcium weight variables--------------------
    gammaP = 13 # 321.808 50.6 
    gammaD = 5.86  # 200
    thP = 2*55
    thD = 2*30

    def Ms_to_step(milsec,dt):
        return int(milsec/(dt * 1e3))
    
    #-------CURRENT-----

    taudec = 1*1e-3 #s   #1ms decay of current
    I0 = .2*1e-12 #current in Amper  ( .1pA)

    B = []
    for it in range(time):
        B.append(I0 * np.exp(-it * dt / taudec))
    train = np.zeros((N_spine,time))
    ISI = 0 #timestep
    #order of the inputs :
    if order == 'outward':
        #time ordered :
        for si in [0,1]:
            train[si,:np.shape(input_strains)[1]] = input_strains[si]
    if order == 'inward':
        for abcd, si in enumerate([1,0]):
            train[abcd,:np.shape(input_strains)[1]] = input_strains[si]

    xs = np.zeros((N_spine,time))  #current I(mA) list for spine


    for spn in range(N_spine):
        cc = np.convolve(train[spn,:], B)
        xs[spn, :] = cc[0:int((len(cc) + 1) / 2)]

#    pl.plot(xs[0],label ='0')
#    pl.plot(xs[1],label='1')
#    pl.legend(loc = 'upper right' )
#    pl.savefig(f'train{order}signal.png',facecolor='w')
#    pl.close()
#
    U_soma = np.zeros(time)
    R_soma = 200*1000#.01   #Gigaohm  #1e10 #ohm #10nS c–300 Mohm
    # R_axial = pr.rl#r_ax_specific*(pr.dl*1e-6)/(np.pi*(pr.radius*1e-2)**2)  #
    R_axial = 10000#.2*R_axial/1e9 #in Gohm5*R_soma#
    V_rest = -70
    U_soma[0]=V_rest
    I_inj = np.zeros(time)
#     I_inj[[300,320,400,450,480,550,600]]=0#pA
    Uth= -66.0
    tausoma = 80 # ms
    rec_spikes=[]
    refractory_time= Ms_to_step(10, dt)
    spikes = np.zeros(time)
    factor_somaV= 1
    
    for t in range(time - 1):

        #----------dendrite and spine potential---------
        weight[:, t+1] = weightexc[:,t] + weightinh[:,t]
        b[0:N_spine,t] = Shead * Eh + Ghead * xs[:, t]* 1e6*(weightexc[:,t] + weightinh[:,t])# current in mA
        b[N_spine:, t] = GAMMA * El
        C = U[:, t] + b[:, t]
        X = linalg.solve(A, C )
        U[:,t+1] = np.asarray(X).flatten()

        #----------soma potential--------------------
        dtms_Soma= 1000*dt #to ms  
        U_soma[t+1]=U_soma[t] +factor_somaV*(dtms_Soma/tausoma )*((V_rest-U_soma[t]) +R_soma*(U[140,t]-U_soma[t])/R_axial)
        #---------------dendrite and spine calcium --------------
        bcal[0:N_spine, t] = gamma * xs[:, t] * (weightexc[:,t] + weightinh[:,t] )#current in Amper
        Ccal = Ucal[:, t] + bcal[:, t]
        Xcal = linalg.solve(Acal, Ccal)
        weightexc[:, t + 1] = weightexc[:, t] + factor*dt * (gammaP * (1 - weightexc[:, t]) * theta( 1e6*Ucal[0:N_spine, t] - thP) - gammaD * weightexc[:, t] * theta( 1e6*Ucal[0:N_spine, t] - thD))
        Ucal[:, t + 1] = np.asarray(Xcal).flatten()

    return N_spine,N_dend,time,dt,thD,thP,Ucal,weight,weightexc, U , U_soma,rec_spikes,Uth

# --------------Run and Plot --------------------------


def Plotting(input_strains, order,variable0,variable1):
    
    path =f'./{variable0_variable1}/result/conf_{order}/'
    N_spine,N_dend,time,dt,thD,thP,Ucal,weight,weightexc, U , U_soma,spikestrace,Uthr = simulation(input_strains,order, variable1)
    steps=time
    xtime=np.linspace(0,(steps*dt*1e3),steps) #*1e3
    spikestrace=np.array(spikestrace)
    # spikestrace.dump(path+"spikestrace.pkl")

    ######################    Ca     ######################
    colors = ['g','b','r','orange']
    for i in range(N_spine):
        pl.plot(xtime, 1e6*Ucal[i, :], '-',label=str(i), c = colors[i])  # , label = 'spine = '+str(i))
    pl.legend(loc = 'upper right' )
    
    pl.title('Ca at spines')
    pl.plot([0, max(xtime)], [thD, thD],'--')
    pl.plot([0, max(xtime)], [thP, thP],'--')
    pl.grid()
    pl.ylabel(' Ca [\u03bc M]')
    pl.xlabel('time(ms)')
    pl.savefig(path+f'Ca_s_{order}.svg',facecolor='w')
    pl.close()
    
    ######################    weight     ###################### 
    for i in range(N_spine):
        pl.plot(xtime,weight[i, :],'-',label=str(i), c = colors[i])
        # pl.show()
    pl.plot([0, max(xtime)], [0.5, 0.5],'--')
    pl.legend(loc = 'upper right' )
    pl.xlabel('time(ms)')
    pl.ylabel('weight')
    pl.ylim(-0.4,0.9)
    pl.savefig(path+f'weight_{order}.svg',facecolor='w')
    pl.close()

    ######################  V_spines  ###################### 
    
    for i in range(N_spine):
        pl.plot(xtime,U[i,:], label= str(i), c = colors[i])
    pl.legend(loc = 'upper right' )

    pl.xlabel('time(ms)')
    pl.ylabel('U(mV)')
    pl.title('spine')
    pl.savefig(path+f'Vspine_{order}.svg',facecolor='w')
    pl.close()
    ######################  V_ Soma   ###################### 
    pl.plot(xtime,U_soma)
    pl.xlabel('time(ms)')
    pl.ylabel('U(mV)')
    pl.ylim(-70.1,-65.0)

    pl.savefig(path+f'Vsoma_{order}.svg',facecolor='w')
    # U_soma.dump(path+f"BFU_soma_{order}.pkl")

    pl.close()
    return weight, weightexc


w_init_trainTotal , w_init_train_exc  = Plotting(signal,order,variable0,variable1)
#_______________________________________________________________________________________________________________________

#_______________________________________________________________________________________________________________________

#----------------After training------------------- :
def simulation_after(input_strains,test_seq,trainedW,variable1):
    order = test_seq
    ############ COMPARTMENTS  ####################
    N_dend = pr.N_dend #No of Dendritic compartment
    N_spine = pr.N_spine  #No of spines
    El  = pr.El #Reversal potential
    time= pr.time  #total time steps
    dt = pr.dt  #dt : time step in second
    dx = pr.dl * 1e-2  #cm to m
    ############ MORPHOLOGY ####################
    cm = pr.cm  #Membrane capacitance in Farad
    cspine = 10*cm#pr.cspine
    ############initial voltage ####################
    Eh = El#pr.Eh
    ####### INPUT###############
    spine_list =  [160,160+int(variable1*4)]#[156 160 162 164 ]#[100,150,200,250]#np.arange(N_spine) #can be 0,1,...(Nd-1)
    adj = np.zeros(N_dend)
    adj[spine_list] = 1
    #####################Calcium#######################3
    Z=2
    Deff =  220 * 1e-12  #m^2/s
    tau = 0.08#10 * 1e-3 #s
    tauspine = 0.08#10 * 1e-3
    Faraday = 96485.309 #C/mol
    y = 0.11
    radius= 1 * 1e-6  #um #den radius
    Lneck = 0.5* 1e-6 #um   #0.16 -1.8 mean .98
    neckradius= 0.1 * 1e-6 #um 0.06-0.29 /2    0.175 mean /2 =0.0875
    spineradius = 0.34 * 1e-6 #  #um 0.26-1.10 /2  mean 0.68 /2 = 0.34
    Vcomp = dx*np.pi*radius**2
    ks =  (4*Deff*neckradius)/Vcomp
    Vs = (4/3)*np.pi*spineradius**3
    tau_prime = Vs/(4*Deff*neckradius) +(Lneck**2)/(2*Deff)
    ks_prime = 1/tau_prime
    rhead =pr.rhead
    rneck=pr.rneck
    ##########################################################3
    SIGMA = dt*(pr.radius*1e-2)/(2*pr.rrl*1e-2*pr.ccm*1e4*(pr.dl*1e-2)**2) #matrix component
    GAMMA = dt/(pr.rrm*(1e-4)*pr.ccm*1e4)  #matrix component
    beta =  dt/(rneck*cm)  #cm is in farad
    Shead=  dt/(rhead*cspine)
    Sneck=dt/(rneck*cspine)
    Ghead =dt/cspine
    sincm=1
    if N_dend==1:
        sincm=0
    A = np.zeros((N_dend+N_spine,N_dend+N_spine))
    for i in range(N_spine+1,N_dend+N_spine-1):
        A[i, i] = 1 + 2*SIGMA + GAMMA +(adj[i-N_spine])*beta
    A[N_spine, N_spine] = 1 + (sincm*SIGMA) + GAMMA +(adj[0])*beta  #first dnd
    A[N_dend+N_spine-1,N_dend+N_spine-1]= 1 + (sincm*SIGMA) + GAMMA + (adj[N_dend-1])*beta
    for i in range(N_spine,N_dend+N_spine-1):
        A[i, i + 1] = -SIGMA
    for i in range(N_spine+1,N_dend+N_spine):
        A[i, i - 1] = -SIGMA
    for i in range(N_spine):
        A[i,i] = 1+Shead+Sneck
    for i in range(N_spine):
        A[i,N_spine+spine_list[i]] = - Sneck
    for i in range(N_spine):
        A[N_spine + spine_list[i],i] = - beta
    b=np.zeros((N_spine+N_dend,time))
    U = np.zeros((N_spine+N_dend,time))  
    U[0:N_spine,0] = Eh
    U[N_spine:N_spine+N_dend,0] = El
    ################################################################
    alpha = dt * ks
    betacal = dt * ks_prime
    F = Deff * dt / dx ** 2
    gamma = dt * y / (Z * Vs * Faraday)
    dec = dt / tau
    decspine = dt / tauspine
    sincm = 1
    if N_dend == 1:
        sincm = 0
    Acal = np.zeros((N_dend + N_spine, N_dend + N_spine))
    for i in range(N_spine + 1, N_dend + N_spine - 1):
        Acal[i, i] = 1 + 2 * F + (adj[i - N_spine]) * alpha + dec
    Acal[N_spine, N_spine] = 1 + (sincm * F) + (adj[0]) * alpha  # first dnd
    Acal[N_dend + N_spine - 1, N_dend + N_spine - 1] = 1 + (sincm * F) + (adj[N_dend - 1]) * alpha
    for i in range(N_spine, N_dend + N_spine - 1):
        Acal[i, i + 1] = -F
    for i in range(N_spine + 1, N_dend + N_spine):
        Acal[i, i - 1] = -F
    for i in range(N_spine):
        Acal[i, i] = 1 + betacal + decspine
    for i in range(N_spine):
        Acal[i, N_spine + spine_list[i]] = - alpha
    for i in range(N_spine):
        Acal[N_spine + spine_list[i], i] = - betacal
    bcal = np.zeros((N_spine + N_dend, time))
    Ucal = np.zeros((N_spine + N_dend, time))
    Ucal[0:N_spine, 0] = 0  # 6.02 * 1e-6
    Ucal[N_spine:N_spine + N_dend, 0] = 0
    def theta(ar):
        listt = np.zeros(len(ar))
        for values in range(len(ar)):
            if ar[values] > 0:
                listt[values] = 1
            if ar[values] <= 0:
                listt[values] = 0
        return listt
    weight = np.zeros((N_spine, time))
    weight[:, 0] = trainedW
    #-----------------CAlcium weight variables--------------------
 
    def Ms_to_step(milsec,dt):
        return int(milsec/(dt * 1e3))
    ###CURRENT
    taudec = 1*1e-3 #s   #1ms decay of current
    I0 = .2*1e-12 #current in Amper  ( .1pA)
    B = []
    for it in range(time):
        B.append(I0 * np.exp(-it * dt / taudec))
    train = np.zeros((N_spine,time))
    #order of the inputs :
    if order == 'outward':
        #time ordered :
        for si in [0,1]:
            train[si,:np.shape(input_strains)[1]] = input_strains[si]
    if order == 'inward':
        for abcd, si in enumerate([1,0]):
            train[abcd,:np.shape(input_strains)[1]] = input_strains[si]

    xs = np.zeros((N_spine,time))  #current I(mA) list for spine
    for spn in range(N_spine):
        cc = np.convolve(train[spn,:], B)
        xs[spn, :] = cc[0:int((len(cc) + 1) / 2)]


#    pl.plot(xs[0],label ='0')
#    pl.plot(xs[1],label='1')
#    pl.legend(loc = 'upper right' )
#    pl.savefig(f'test{order}signal.png',facecolor='w')
#    pl.close()
#
    U_soma = np.zeros(time)
    R_soma = 200*1000#.01   #Gigaohm  #1e10 #ohm #10nS c–300 Mohm
    R_axial = 10000#.2*R_axial/1e9 #in Gohm5*R_soma#
    V_rest = -70
    U_soma[0]=V_rest
    I_inj = np.zeros(time)
    Uth= -66.0
    tausoma = 80 # ms

    spikes = np.zeros(time)
    factor_somaV= 1

    tr = 0.
    crossing_times = []
    above_threshold = False
    for t in range(time - 1):
        #----------dendrite and spine potential---------
        b[0:N_spine,t] = Shead * Eh + Ghead * xs[:, t]*1e6*(weight[:,t]) # current in mA
        b[N_spine:, t] = GAMMA * El
        C = U[:, t] + b[:, t]
        X = linalg.solve(A, C )
        U[:,t+1] = np.asarray(X).flatten()
        #----------soma potential--------------------
        dtms_Soma= 1000*dt #to ms
        dendterm = R_soma*(U[140,t]-U_soma[t])/R_axial
        U_soma[t+1]=U_soma[t] +(dtms_Soma/tausoma )*(R_soma*I_inj[t] +(V_rest-U_soma[t]) +dendterm)
        if not above_threshold and U_soma[t-1] <Uth and U_soma[t]>=Uth:
            crossing_times.append(t)
            above_threshold = True
        elif U_soma[t] <Uth:
            above_threshold = False
        weight[:, t + 1] = weight[:, t] 
    return N_spine,N_dend,time,dt,test_seq,weight, U , U_soma,crossing_times,Uth


#--------------------Run and Plot --------------------



def Plotting_after(test_Strains,trainedW,trained_seq,test_seq,variable0,variable1):

    path =f'./{variable0_variable1}/resultafter{trained_seq}/conf_{test_seq}/'
    N_spine,N_dend,time,dt,seqafter,weight, U , U_soma ,crossing_times,Uthr = simulation_after(test_Strains,test_seq,trainedW,variable1)
    steps = time
    xtime=np.linspace(0,(steps*dt*1e3),steps) #*1e3

    ######################  V_ Soma   ###################### 
    pl.plot(xtime,U_soma)
    pl.ylim(-70.1,-65.0)
    #T= np.round(np.array(spikestrace) *pr.dt*1e3,3)
    pl.plot([0,xtime[-1]],[Uthr,Uthr],color='r')
    pl.xlim(0,100)
    pl.savefig(path+f'soma_d_{seqafter}.svg',facecolor='w')
    np.savetxt(path+ f"crossing_times.txt", crossing_times)
    
    pl.close()
    return [70-abs(U_soma.max())]



trained_seq = order #0 5 6 7  13 14
w_t = list(w_init_trainTotal[:,-1])
test_seq = 'outward'   # 'or'  'rnd1'   'rnd2' 
time= pr.time
config = [1,1]
os.makedirs(f"./{variable0_variable1}/resultafter{trained_seq}/conf_{test_seq}", exist_ok=True)
time= pr.time
signal = np.zeros((2,time))
input_duration  = 10
input_delay  = input_delay
initial_ignt = 50
signal[:,initial_ignt:input_duration+initial_ignt] = [[i] for i in config ]
signal[1] =  np.roll(signal[1],input_delay)
Usmax_out = Plotting_after(signal,w_t,trained_seq,test_seq,variable0,variable1)



#Second test :

trained_seq = order #0 5 6 7  13 14
w_t = list(w_init_trainTotal[:,-1])
test_seq = 'inward'   # 'or'  'rnd1'   'rnd2' 
time= pr.time
config = [1,1]
os.makedirs(f"./{variable0_variable1}/resultafter{trained_seq}/conf_{test_seq}", exist_ok=True)
time= pr.time
signal = np.zeros((2,time))
input_duration  = 10
input_delay  = input_delay
initial_ignt = 50
signal[:,initial_ignt:input_duration+initial_ignt] = [[i] for i in config ]
signal[1] =  np.roll(signal[1],input_delay)
Usmax_in = Plotting_after(signal,w_t,trained_seq,test_seq,variable0,variable1)
Uth = -66.0
Ucros =70+Uth
crostr = 0
if Usmax_out > Usmax_in:
    if Usmax_out[0]>=Ucros:
        crostr = 1
    np.savetxt(f"./{variable0_variable1}/resultafter{trained_seq}/Usmax_out.txt", [Usmax_in[0],Usmax_out[0],Usmax_in[0]/Usmax_out[0],crostr,abs(Usmax_in[0]-Usmax_out[0])])
if Usmax_out < Usmax_in:
    if Usmax_in[0]>=Ucros:
        crostr = 1
    np.savetxt(f"./{variable0_variable1}/resultafter{trained_seq}/Usmax_in.txt", [Usmax_in[0],Usmax_out[0],Usmax_in[0]/Usmax_out[0],crostr,abs(Usmax_in[0]-Usmax_out[0])])
if Usmax_out == Usmax_in:
    if Usmax_out[0]>=Ucros:
        crostr = 1
    np.savetxt(f"./{variable0_variable1}/resultafter{trained_seq}/Usmax_tie.txt",[Usmax_in[0],Usmax_out[0],Usmax_in[0]/Usmax_out[0],crostr,abs(Usmax_in[0]-Usmax_out[0])])




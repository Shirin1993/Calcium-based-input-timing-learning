
import matplotlib.pyplot as pl
import numpy as np
import itertools as itertools
import os

jobid = os.getenv('SLURM_ARRAY_TASK_ID')
jobid = int(jobid)-1


thP = 4
thD = 2

Depression_coef = np.linspace(0.1,10,20)
Potentiation_coef = np.linspace(0.1,10,20)
coefficient = np.round(list(itertools.product(Depression_coef,Potentiation_coef)),3)


colors =['b','r'] #blue :spine 1 red Spine 2

icoef = coefficient[jobid]
gammaP = icoef[0]
gammaD = icoef[1]


N_spine = 2
for sp in range(N_spine):
    path = f'/scratch/users/shafieekamal/GeneralRuns/bashrun/STDP/coefficient/burstsize1/gammaP{gammaP}_gammaD{gammaD}'# os.getcwd()
    # path = path+'/burstsize1/thP1.0_thD1.0'
    #'/home/shirin/Desktop/pych/venv/diff/calEuler/CaTauD/burst/2synapse/w/'
    
    delays = [0, 2,4,6,8,10,15,20,30,40,50,60,80,100,150,200]#[-15,-10,  -5, 0 ,5 ,10,15]# [-10, -8,-6,-4,-2,0 , 2,4 ,6,8,10]#[-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0 , 1 ,2, 3, 4 ,5,6,7,8,9,10]
    spine = sp
    timesampling = 999
    delta_w = []
    dt = 25 * 1e-5#s   #timestep
    def ttoms(milsec):
        dt = 25 * 1e-5#s   #timestep
        return int(milsec/(dt * 1e3))
    for delay in delays[::-1]: #Negaive delays
        weights = np.loadtxt(path +'/n/'+ 'w_thetp'+ str(thP) +'delay'+str(delay)+'.txt')
        delta_w.append((weights[spine, ttoms(timesampling)]/weights[spine, 0])  )


    for delay in delays[1:]:
        weights = np.loadtxt(path+'/p/'+ 'w_thetp'+ str(thP) +'delay'+str(delay)+'.txt')
        delta_w.append((weights[spine, ttoms(timesampling)]/weights[spine, 0])  )

        # pl.plot(weights[spine,:])
        # pl.show()
    delaylist = [-i for i in (delays[:0:-1])]+delays
#    delaylist.pop(len(delays)-1)
#    delta_w.pop(len(delays)-1)
    pl.plot(delaylist,delta_w,'-o',color = colors[sp],label=f'spine{spine}')#,label='w_max = '+str(weights[spine, ttoms(299)]/weights[spine, 0]))
pl.title(f'gammaP : {gammaP} gammaD : {gammaD}')
pl.legend()#
pl.ylabel('synaptic weights $(w_f/w_init )  $ ')
pl.xlabel('time differences (ms)')
a0=0.85#min(delta_w)-0.2
b0=1.15#max(delta_w)+0.1
pl.ylim(a0,b0)
pl.plot([min(delaylist),max(delaylist)],[1,1],'--' , color ='0.5')
pl.plot( [0,0],[a0,b0],'--',color ='0.5')
pl.savefig(f'/scratch/users/shafieekamal/GeneralRuns/bashrun/STDP/coefficient/plots_rev/gammaP{gammaP}_gammaD{gammaD}.svg')
pl.close()



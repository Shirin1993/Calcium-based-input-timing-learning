
import matplotlib.pyplot as plt
import numpy as np
import itertools as itertools
import os
from matplotlib.colors import ListedColormap, BoundaryNorm
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap
import matplotlib as mpl 
mpl.rcParams["svg.fonttype"] = "none"


def pn(original_binary_list): #convert the sign list to p or d list 
    modified = ['P' if element == 1 else 'D' for element in original_binary_list]
    modified =  [x for x, y in zip(modified, modified[1:] + [None]) if x != y]
    return ''.join(map(str, list((modified))))



def colorcodef(sp):
    colorcode = []
    # jobid = os.getenv('SLURM_ARRAY_TASK_ID')
    for jobid in range(400):
    
        Depression_thr = np.linspace(0.1,10,20)
        Potentiation_thr = np.linspace(0.1,10,20)
        threshold = np.round(list(itertools.product(Depression_thr,Potentiation_thr)),3)
                
        ith = threshold[jobid]
        thP = ith[0]
        thD = ith[1]
        N_spine = 2
        delays = [0, 2,4,6,8,10,15,20,30,40,50,60,80,100]
        signes = np.zeros((N_spine,2*len(delays)-1) )

        path = f'/scratch/users/shafieekamal/GeneralRuns/bashrun/STDP/Distance2_spike1/burstsize1/thP{thP}_thD{thD}'# os.getcwd()

        
        spine = sp
        timesampling = 999
        delta_w = []
        dt = 25 * 1e-5#s   #timestep
        def ttoms(milsec):
            dt = 25 * 1e-5#s   #timestep
            return int(milsec/(dt * 1e3))
        for idelay,delay in enumerate(delays[::-1]): #Negaive delays
            weights = np.loadtxt(path +'/n/'+ 'w_thetp'+ str(thP) +'delay'+str(delay)+'.txt')
            delta_w.append((weights[spine, ttoms(timesampling)]/weights[spine, 0])  )
            if delta_w[-1]>1.0000:
                signes[spine,idelay]=1
            if delta_w[-1]<1.0000:
                signes[spine,idelay]=-1

        
        for idelay,delay in enumerate(delays[1:]):# the element in the middle which is zero should be count once thats why I put 1  here 
            weights = np.loadtxt(path+'/p/'+ 'w_thetp'+ str(thP) +'delay'+str(delay)+'.txt')
            delta_w.append((weights[spine, ttoms(timesampling)]/weights[spine, 0])  )
            if delta_w[-1]>1.0000:
                signes[spine,idelay+len(delays)]=1
            if delta_w[-1]<1.0000:
                signes[spine,idelay+len(delays)]=-1
        
        colorcode.append(pn(signes[spine]))
    return(colorcode)




def plotPD(listcolorcode,spinenum):
    # Your matrix with string elements
    # Your matrix with string elements

    TheList = {
        0: ('P', '#ff0000'),
        1: ('D', '#0000ff'),
        2: ('PD', '#800080'),
        3: ('DP', '#a52a2a'),
        4: ('PDP', '#8b0000'),
        5: ('DPD', '#00008b'),
        6: ('PDPD', '#00ffff'),
        7: ('DPDP', '#ffc0cb'),
        8: ('PDPDP', '#fa8072'),
        9: ('DPDPD', '#e6e6fa'),
        10 : ('PDPDPD', '#ffff00')
    }



    colorsAll = [(0.0, '#ff0000'),
     (0.1, '#0000ff'),
     (0.2, '#800080'),
     (0.3, '#a52a2a'),
     (0.4, '#8b0000'),
     (0.5, '#00008b'),
     (0.6, '#00ffff'),
     (0.7, '#ffc0cb'),
     (0.8, '#fa8072'),
     (0.9, '#e6e6fa'),
     (1.0, '#ffff00')]
    custom_color_map = LinearSegmentedColormap.from_list(name='custom_cc',colors=colorsAll)
    

    possiblePD =  list(set(listcolorcode))
    mylist = np.reshape((listcolorcode),(20,20))
    colors= {element: key for key, (code, color) in TheList.items() for element in possiblePD if code == element} # inja before /10 bayad bashe


    mylist=np.array([[colors[element] for element in row] for row in mylist])
    mylist=mylist
    mylist=mylist/10 # normalized to 0-1
    datacolorcode = np.array(sorted(colors.values()))/10

    Ex = []
    Existed =[]
    for i in range(len(colorsAll)):
        if colorsAll[i][0] in datacolorcode :
            Ex.append(colorsAll[i][1])
    normal = np.linspace(0,1,len(Ex))
    for i, element in enumerate(Ex):
        Existed.append((normal[i],element))



    custom_color_map_final = LinearSegmentedColormap.from_list('Custom', Existed, len(Existed))


    # Your matrix of values
    original_matrix = mylist
    # Given range
    Ex =sorted(set(mylist.flatten()))
    # Creating a new matrix with values mapped to np.linspace(0, 1, len(Ex))
    new_matrix = np.linspace(0, 1, len(Ex))
    # Mapping the values using linear interpolation
    mapped_matrix = np.interp(original_matrix, Ex, new_matrix)


    ax = sns.heatmap(mapped_matrix, cmap=(custom_color_map_final))
    ax.invert_yaxis()
    ax.set_xticklabels( np.round(np.linspace(0.1,10,20),2), rotation = 90)
    ax.set_yticklabels(np.round(np.linspace(0.1,10,20),2), rotation = 0)
    # Get the colorbar object from the Seaborn heatmap
    colorbar = ax.collections[0].colorbar
    r = (colorbar.vmax - colorbar.vmin)
    numcolors =len(Existed)
    colorbar.set_ticks([colorbar.vmin + 0.5 * r / (numcolors) + r * i / (numcolors) for i in range(numcolors)])
    colorbar.set_ticklabels([TheList[key][0] for key in colors.values()])



    plt.xlabel(r"${\theta_d}$")
    plt.ylabel(r"${\theta_p}$")
    plt.savefig(f'heatmap_spine_{spinenum}.svg', bbox_inches='tight')
    plt.close()
    # plt.show()



plotPD(colorcodef(0), 0)
plotPD(colorcodef(1), 1)

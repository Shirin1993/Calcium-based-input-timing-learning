import sys
import pylab as pl
#from scitools import *
import scipy.sparse
import scipy.sparse.linalg
import numpy as np
from scipy import linalg
import random as rnd
import itertools as itertools
import os



jobid = os.getenv('SLURM_ARRAY_TASK_ID')
jobid = int(jobid)-1


numberofspike = 2
numberOfBursts = 1  # number of bursts

thP = 4
thD = 2



Depression_coef = np.linspace(0.1,10,20)
Potentiation_coef = np.linspace(0.1,10,20)
coefficient = np.round(list(itertools.product(Potentiation_coef,Depression_coef)),3)

ppath = '/scratch/users/shafieekamal/GeneralRuns/bashrun/STDP/Triplet/coefficient/'
parent_dir = os.path.join(ppath, f"burstsize{numberofspike}")



os.makedirs(f"{parent_dir}", exist_ok=True)
icoef = coefficient[jobid]
gammaP = icoef[0]
gammaD = icoef[1]
os.makedirs(f"{parent_dir}/gammaP{gammaP}_gammaD{gammaD}", exist_ok=True)
path =  f"{parent_dir}/gammaP{gammaP}_gammaD{gammaD}/"
#os.makedirs(path +"/p", exist_ok=True)
#path = path+'p/'



N_spine = 2  # number of spines
N_dend = 320  # number of dendritic segments
L = 80 * 1e-6  # 10 um     #Total length of dendritic branch in [m]
dx = L / (N_dend)  # Length of each dendritic segments in [m]
timetotal = 1000 * 1e-3  # Total time of simulation in [s]
dt = 25 * 1e-5  # s   #Timestep duration in [s]
time = int(timetotal / dt)  # Number of steps


spine_list = [160, 164]  # 36 40 44 48 52 56 60 64 68 72    


# Ca Parameters
Z = 2  # Calcium valance
Deff = 220 * 1e-12  # diffusion coefficient of calcium in dendrite in [m^2/s ]
tau = 0.08  # Decay time of dendrite (Inactivation Time constant ) in [s]
tauspine = 0.08  # Decay time of spine (Inactivation Time constant ) in [s]
Faraday = 96485.309  # Faraday constant [C/mol]
y = 0.11  # Fraction of current carried by calcium through the receptor

# Geometrical parameters
radius = 1 * 1e-6  # dendritic radius in [m]
Lneck = 0.5 * 1e-6  # spine neck length in [m]   #0.16 -1.8 mean .98
neckradius = 0.1 * 1e-6  # spine neck radius in [m]   0.06-0.29 /2    0.175 mean /2 =0.0875
spineradius = 0.34 * 1e-6  # #spine radius in [m]  0.26-1.10 /2  mean 0.68 /2 = 0.34
S = np.pi * radius ** 2  # surface of dendritic cross-section pi*radius^2
S_prime = np.pi * neckradius ** 2  # surface of spine neck cross-section pi*neckradius^2
Vcomp = dx * np.pi * radius ** 2  # dednritic segments volume dx*pi*r^2

ks = (4 * Deff * neckradius) / Vcomp  # rate of Ca influx from dend to spine neck (small hole theory) (Biess et al. 2011)
Vs = (4 / 3) * np.pi * spineradius ** 3  # Spine volume 4/3*pi*r^3
tau_prime = Vs / (4 * Deff * neckradius) + (Lneck ** 2) / (
            2 * Deff)  # mean sojourn time of a diffusing molecule inside spine (Biess et al. 2007)
ks_prime = 1 / tau_prime  # rate of Ca influx from spine to dend (Biess et al. 2007)

# synaptic weight parameters

w0 = 0.5  # initial synaptic weight of spine 1
w1 = 0.5  # initial synaptic weight of spine 1

  # ,48]   # spine location ( attached dendritic segment )
adj = np.zeros(N_dend)  # dednd adjacent list (dend-spine connection)
adj[spine_list] = 1
delays = [-150,-100,-80,-60,-40,-50,-30,-20,-15,-10,-8,-6,-4,-2,0, 2, 4, 6, 8, 10, 15, 20, 30, 40, 50, 60, 80, 100, 150 ]  # delays between 2 spines inputs
taudec = 1 * 1e-3  # synaptic input current decay time in [s]
I0 = 0.1 * 1e-12  # synaptic input current in [A]   , order of 1 [pA]


def location(i, dx):
    '''
    convert index to the location on dendrite
    i : index
    dx : Length of a dendritic segment
    '''
    return np.round(1e6 * (2 * i + 1) * dx / 2, 4)


##########################################################

def ttoms(milisec, dtt):
    '''
    convert ms to simulation time
    currenttimestep : simulation timestep
    dtt : timestep in [s]
    '''
    return int(milisec / (dtt * 1e3))


input_time = ttoms(200, dt)  # first current input time

B = []  # needed current convolution
for it in range(time):
    B.append(I0 * np.exp(-it * dt / taudec))

for dly in delays:
    train = np.zeros((N_spine, time))  # current I(mA) list for spine

    dts = ttoms(20, dt)  # time interval between single spikes [timestep]
    delay = ttoms(dly, dt)  # delays between 2 spines inputs [timestep]
    interval = ttoms(0, dt)  # delays between 2 bursts [timestep]

    for d in range(numberOfBursts):
        for i in range(numberofspike):
            tt = i * dts
            train[0, d * interval + input_time + i * dts] = 1
        train[1, input_time + d * interval + delay] = 1

    # current convolution
    xs = np.zeros((N_spine, time))
    for spn in range(N_spine):
        cc = np.convolve(train[spn, :], B)
        xs[spn, :] = cc[0:int((len(cc) + 1) / 2)]

    # creating matrix for differential eq. and defining parameters
    alpha = dt * ks
    beta = dt * ks_prime
    F = Deff * dt / dx ** 2
    gamma = dt * y / (Z * Vs * Faraday)
    dec = dt / tau
    decspine = dt / tauspine

    sincm = 1
    if N_dend == 1:
        sincm = 0
    A = np.zeros((N_dend + N_spine, N_dend + N_spine))
    for i in range(N_spine + 1, N_dend + N_spine - 1):
        A[i, i] = 1 + 2 * F + (adj[i - N_spine]) * alpha + dec
    A[N_spine, N_spine] = 1 + (sincm * F) + (adj[0]) * alpha  # first dnd
    A[N_dend + N_spine - 1, N_dend + N_spine - 1] = 1 + (sincm * F) + (adj[N_dend - 1]) * alpha
    for i in range(N_spine, N_dend + N_spine - 1):
        A[i, i + 1] = -F
    for i in range(N_spine + 1, N_dend + N_spine):
        A[i, i - 1] = -F
    for i in range(N_spine):
        A[i, i] = 1 + beta + decspine
    for i in range(N_spine):
        A[i, N_spine + spine_list[i]] = - alpha
    for i in range(N_spine):
        A[N_spine + spine_list[i], i] = - beta

    b = np.zeros((N_spine + N_dend, time))
    U = np.zeros((N_spine + N_dend, time))

    U[0:N_spine, 0] = 0  # 6.02 * 1e-6 #inintial values for calcium concentration
    U[N_spine:N_spine + N_dend, 0] = 0


    def theta(ar):  # Heaviside func for calcium thresholding
        listt = np.zeros(len(ar))
        for values in range(len(ar)):
            if ar[values] > 0:
                listt[values] = 1
            if ar[values] <= 0:
                listt[values] = 0
        return listt


    weight = np.zeros((N_spine, time))

    weight[0, 0] = w0
    weight[1, 0] = w1
    #     print(weight[0,0],weight[1,0])



    # Solve Backward Euler for calcium diffusion eq.
    for t in range(time - 1):
        b[0:N_spine, t] = gamma * xs[:, t] * weight[:, t]
        C = U[:, t] + b[:, t]
        X = linalg.solve(A, C)
        weight[:, t + 1] = weight[:, t] + dt * (
                    gammaP * (1 - weight[:, t]) * theta(1e6 * U[0:N_spine, t] - thP) - gammaD * weight[:, t] * theta(
                1e6 * U[0:N_spine, t] - thD))
        U[:, t + 1] = np.asarray(X).flatten()

    np.savetxt(path + 'w_' + "thetp" + str(thP) + "delay" + str(dly) + '.txt', weight, fmt='%1.5e')

    # Calculate time spent above thresholds
#    for isp in range(N_spine):
#        upthetaP = len((np.where(1e6 * U[isp, :] > thP))[0]) * dt * 1e3
#        upthetaD = len((np.where(1e6 * U[isp, :] > thD))[0]) * dt * 1e3
#        with open(path + 'time' + 'spine' + str(isp) + "thetp" + str(thP) + "delay" + str(dly) + '.txt', 'w') as f:
#            f.write(str(upthetaP))
#            f.write('\n')
#            f.write(str(upthetaD))
#        f.close()


